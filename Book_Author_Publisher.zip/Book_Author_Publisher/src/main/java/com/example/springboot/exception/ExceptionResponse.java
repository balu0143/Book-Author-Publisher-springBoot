package com.example.springboot.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExceptionResponse {

	public ExceptionResponse(int value, String message) {
		// TODO Auto-generated constructor stub
	}
	private Integer code;
    private String status;
}
