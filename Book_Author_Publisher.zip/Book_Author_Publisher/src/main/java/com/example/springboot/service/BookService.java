package com.example.springboot.service;

import com.example.springboot.entity.Book;

public interface BookService {
	
	public Book getBooks(Integer id);

	  public  Book addBooks(Book book);

}
