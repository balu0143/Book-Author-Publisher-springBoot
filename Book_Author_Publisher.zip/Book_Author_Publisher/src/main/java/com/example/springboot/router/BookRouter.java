package com.example.springboot.router;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.entity.Book;
import com.example.springboot.service.BookService;

@RestController
@RequestMapping("book")
public class BookRouter {
	 @Autowired
	    private BookService bookService;

	    @GetMapping("/{id}")
	    public Book  getBooks(@PathVariable Integer id){
	        return bookService.getBooks(id);

	    }
	    @PostMapping("/addbook")
	    public Book addBooks(@RequestBody Book book){
	        return bookService.addBooks(book);
	    }

}
