package com.example.springboot.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.example.springboot.entity.Author;
import com.example.springboot.entity.Publisher;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Book {

	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer bookId;
	    private String bookName;

	    @OneToMany(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	    @JoinColumn(name = "Book_Id",referencedColumnName = "bookId")
	    List<Author> author;
	    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	    private  Publisher publisher;
}
